export function buildSupportPrompt(storeName: string, ticketBody: string, order: any) {
  return `You are a senior support agent for ${storeName}, a Shopify store.

Customer email: ${ticketBody}

Order context:
Order ID: ${order?.shopify_order_id || 'Not found'}
Status: ${order?.status || 'Unknown'}
Tracking: ${order?.tracking || 'No tracking yet'}
Customer Email: ${order?.email || 'N/A'}

TASK: Draft a 3-4 sentence, warm, helpful reply that:
- Acknowledges their concern
- Gives exact order status + tracking link if shipped (format as: https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels=${order?.tracking || ''} - make it generic)
- If not shipped, say warehouse is packing and give ETA
- Do NOT promise refund unless explicitly allowed. Do NOT hallucinate tracking.
- End with first name of brand signature.

Reply in Gmail-ready tone, no subject line, no placeholders.`;
}
