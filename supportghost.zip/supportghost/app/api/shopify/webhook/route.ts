import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';

export async function POST(req: NextRequest) {
  const body = await req.json();
  // Shopify order payload - simplified
  const orderId = body.id?.toString() || body.name || 'unknown';
  const email = body.email || body.customer?.email || '';
  const status = body.fulfillment_status || 'unfulfilled';
  const tracking = body.fulfillments?.[0]?.tracking_number || '';

  await supabaseAdmin.from('orders_cache').upsert({
    shopify_order_id: orderId,
    email: email,
    status: status,
    tracking: tracking,
  });

  return NextResponse.json({ ok: true });
}
