import { NextRequest, NextResponse } from 'next/server';
import { stripe } from '@/lib/stripe';
export async function POST(req: NextRequest) {
  const payload = await req.text();
  // Verify signature in prod: stripe.webhooks.constructEvent...
  return NextResponse.json({ received: true });
}
