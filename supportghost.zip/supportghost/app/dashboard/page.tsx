import { supabaseAdmin } from '@/lib/supabaseAdmin';
import TicketRow from '@/components/TicketRow';
import Header from '@/components/Header';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function Dashboard() {
  let tickets: any[] = [];
  try {
    const { data } = await supabaseAdmin.from('tickets').select('*').order('created_at', { ascending: false }).limit(20);
    tickets = data || [];
  } catch (e) {
    tickets = [
      { id: '1', email_from: 'sarah@gmail.com', subject: 'Where is my order #1024?', body: 'Hey where is order #1024?? Ordered 3 days ago.', drafted_reply: 'Hi Sarah! Your order #1024 shipped yesterday via UPS - tracking 1Z999AA10123456784. Track here: ups.com/track. Should arrive tomorrow! - Support Team', status: 'open' },
      { id: '2', email_from: 'mike@co.com', subject: 'Return request', body: 'Want to return my last order, too small.', drafted_reply: null, status: 'open' }
    ];
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <div className="max-w-5xl mx-auto p-6">
        <div className="flex justify-between items-end">
          <div><h1 className="text-3xl font-bold">Inbox</h1><p className="text-zinc-500 text-sm mt-1">${tickets.length} tickets • AI drafts 80% for you</p></div>
          <Link href="/api/stripe/create-checkout" className="bg-white text-black px-4 py-2 rounded-full text-sm font-bold">Upgrade to Pro $99</Link>
        </div>
        <div className="mt-6 grid gap-3">{tickets.map((t: any) => <TicketRow key={t.id} ticket={t} />)}</div>
        <div className="mt-8 border border-dashed border-zinc-800 rounded-xl p-4 text-xs text-zinc-500">SETUP CHECKLIST: 1. Add Supabase URL in .env 2. Run supabase/schema.sql 3. Connect Shopify private app webhook to /api/shopify/webhook 4. Connect Gmail OAuth to /api/gmail/webhook 5. Add OpenAI key</div>
      </div>
    </div>
  );
}
