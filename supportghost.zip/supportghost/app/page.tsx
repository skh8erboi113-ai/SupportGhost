import Link from "next/link";
export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white p-6">
      <div className="max-w-5xl mx-auto">
        <nav className="flex justify-between py-6"><span className="font-bold text-xl">👻 SupportGhost</span><Link href="/dashboard" className="bg-white text-black px-4 py-2 rounded-full text-sm font-bold">Dashboard</Link></nav>
        <div className="mt-20">
          <div className="inline-block border border-zinc-800 rounded-full px-3 py-1 text-xs text-zinc-400 mb-4">SHOPIFY APP • LIVE ON 12 STORES</div>
          <h1 className="text-5xl md:text-7xl font-bold leading-[0.9] tracking-tight">Stop answering<br/><span className="text-zinc-500">"Where is my order?"</span></h1>
          <p className="mt-6 text-xl text-zinc-400 max-w-xl">SupportGhost plugs into Shopify + Gmail. Reads order status + tracking, auto-drafts 80% of support replies. You approve in 1 click.</p>
          <div className="mt-8 flex gap-3">
            <Link href="/dashboard" className="bg-white text-black px-6 py-3 rounded-full font-bold">Start Free Trial</Link>
            <span className="px-6 py-3 rounded-full border border-zinc-800 text-zinc-400">$49/mo after 14 days</span>
          </div>
          <div className="mt-16 grid md:grid-cols-3 gap-4 text-sm">
            <div className="border border-zinc-900 p-4 rounded-2xl"><b className="text-white">✓ Shopify Order Sync</b><p className="text-zinc-500 mt-1">Auto-pull status, tracking, fulfillment.</p></div>
            <div className="border border-zinc-900 p-4 rounded-2xl"><b className="text-white">✓ AI Drafts in Gmail Voice</b><p className="text-zinc-500 mt-1">Trained on your past tickets.</p></div>
            <div className="border border-zinc-900 p-4 rounded-2xl"><b className="text-white">✓ 1-Click Approve</b><p className="text-zinc-500 mt-1">Send via Gmail API, no copy-paste.</p></div>
          </div>
          <div className="mt-12 border border-zinc-900 rounded-2xl p-4 bg-zinc-950"><p className="text-xs text-zinc-500">DEMO TICKET</p><p className="mt-2 text-sm">Customer: "Hey where is order #1024??"<br/>Shopify: Order #1024 - Shipped, Tracking 1Z999...<br/>AI Draft: "Hi Sarah! Your order #1024 shipped yesterday via UPS - tracking 1Z999... You can track here: [link]. Should arrive tomorrow! - Team"</p></div>
        </div>
      </div>
    </main>
  );
}
