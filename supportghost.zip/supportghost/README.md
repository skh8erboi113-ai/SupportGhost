# 👻 SupportGhost - AI Shopify Support SaaS (Phone Built)

Full-stack app you can build and sell on GitHub, 100% from phone.

## What it does
Shopify + Gmail -> AI drafts 80% of "Where is my order?" tickets. Merchant approves in 1 click. Saves 15h/week.

## Why it sells for high
Shopify app aggregators buy at 36-50x MRR. $500 MRR = $18k, $2k MRR = $80k. Repo includes Stripe, Supabase, OpenAI.

## Build on Phone Only

### 1. Create GitHub Repo
GitHub Mobile App > + > New Repo > name `supportghost` > Public

### 2. Open in Codespaces (on phone)
In mobile Chrome, go to: github.dev/YOURUSERNAME/supportghost
Or: github.com/YOURUSERNAME/supportghost > Code > Codespaces > Create Codespace

### 3. Upload these files
In github.dev, drag-drop all files from this zip, or copy-paste each file content.
Or in Codespace terminal, run:
```
git clone https://github.com/YOURUSERNAME/supportghost .
```
Then upload.

### 4. Install + Env
In Codespace terminal (bottom panel):
```
npm install
cp .env.example .env.local
```
Edit .env.local with your keys:
- Supabase: supabase.com > New Project (free) > copy URL + anon + service_role
- OpenAI: platform.openai.com > API key
- Stripe: dash.stripe.com > test keys for now

### 5. Run DB
Supabase > SQL Editor > paste supabase/schema.sql > Run

### 6. Dev
```
npm run dev
```
Open preview link in Codespace.

### 7. Deploy
Vercel App on phone > Add New Project > Import GitHub repo > Add same env vars > Deploy. Auto-deploys on git push.

### 8. Get users & Sell
- Reddit r/shopify: "I built free tool to auto-draft WISMO replies, free for 5 stores"
- Get 10 paying $49 = $490 MRR
- List on Acquire.com: Connect Stripe, upload Loom demo, transfer GitHub repo.

### Files included
- app/page.tsx = landing
- app/dashboard/page.tsx = inbox with AI drafts
- app/api/draft = OpenAI drafting logic
- app/api/shopify/webhook = order sync
- app/api/gmail/webhook = ticket ingest
- lib/prompts.ts = your AI moat
- supabase/schema.sql = DB

To flip for max: Add 1 Loom video /dashboard demo, add Stripe MRR screenshot. Buyers pay more for clean README + env.example.

Good luck - ship today, sell in 30 days.
