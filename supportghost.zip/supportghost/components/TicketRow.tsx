"use client";
export default function TicketRow({ ticket }: { ticket: any }) {
  async function approve() {
    const res = await fetch('/api/draft', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'send', ticketId: ticket.id }) });
    alert(res.ok ? 'Sent via Gmail API (mock)' : 'Error');
  }
  return (
    <div className="border border-zinc-800 rounded-xl p-4 bg-zinc-950">
      <div className="flex justify-between text-xs text-zinc-500"><span>{ticket.email_from}</span><span>{ticket.status}</span></div>
      <p className="mt-2 text-sm font-bold">{ticket.subject}</p>
      <p className="mt-1 text-sm text-zinc-400">{ticket.body?.slice(0,120)}</p>
      <div className="mt-3 bg-black border border-zinc-800 p-3 rounded-lg text-sm text-zinc-200">{ticket.drafted_reply || 'No draft yet - click Generate'}</div>
      <div className="mt-3 flex gap-2">
        <button onClick={async()=>{
          const r = await fetch('/api/draft', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'generate', ticketId: ticket.id})});
          location.reload();
        }} className="bg-white text-black px-3 py-1.5 rounded-full text-xs font-bold">Generate Draft</button>
        <button onClick={approve} className="border border-zinc-700 px-3 py-1.5 rounded-full text-xs">Approve & Send</button>
      </div>
    </div>
  );
}
